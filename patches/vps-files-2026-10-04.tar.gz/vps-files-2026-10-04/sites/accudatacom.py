from DrissionPage import ChromiumPage, ChromiumOptions
from time import sleep
import json
import random
import os, datetime, pyautogui, sys, requests
from twocaptcha import TwoCaptcha
from lib.common import generate_email, generate_phone_number

api_key = os.getenv("TWOCAPTCHA_API_KEY", "")
solver = TwoCaptcha(api_key)

now = datetime.datetime.now()
current_date = now.strftime("%Y-%m-%d")
base_dir = os.getcwd()

screentShotDir = os.path.join(base_dir, "ScreenShot", current_date)

os.makedirs(screentShotDir, exist_ok=True)
usaStateDictionary = { 'Alabama': 'AL', 'Alaska': 'AK', 'Arizona': 'AZ', 'Arkansas': 'AR', 'California': 'CA', 'Colorado': 'CO', 'Connecticut': 'CT', 'Delaware': 'DE', 'District of Columbia': 'DC', 'Florida': 'FL', 'Georgia': 'GA', 'Hawaii': 'HI', 'Idaho': 'ID', 'Illinois': 'IL', 'Indiana': 'IN', 'Iowa': 'IA', 'Kansas': 'KS', 'Kentucky': 'KY', 'Louisiana': 'LA', 'Maine': 'ME', 'Maryland': 'MD', 'Massachusetts': 'MA', 'Michigan': 'MI', 'Minnesota': 'MN', 'Mississippi': 'MS', 'Missouri': 'MO', 'Montana': 'MT', 'Nebraska': 'NE', 'Nevada': 'NV', 'New Hampshire': 'NH', 'New Jersey': 'NJ', 'New Mexico': 'NM', 'New York': 'NY', 'North Carolina': 'NC', 'North Dakota': 'ND', 'Ohio': 'OH', 'Oklahoma': 'OK', 'Oregon': 'OR', 'Pennsylvania': 'PA', 'Rhode Island': 'RI', 'South Carolina': 'SC', 'South Dakota': 'SD', 'Tennessee': 'TN', 'Texas': 'TX', 'Utah': 'UT', 'Vermont': 'VT', 'Virginia': 'VA', 'Washington': 'WA', 'West Virginia': 'WV', 'Wisconsin': 'WI', 'Wyoming': 'WY' }


def get_chromium_options(arguments: list) -> ChromiumOptions:
    """
    Configures and returns Chromium options.
    
    :param browser_path: Path to the Chromium browser executable.
    :param arguments: List of arguments for the Chromium browser.
    :return: Configured ChromiumOptions instance.
    """
    options = ChromiumOptions()
    # options.no_imgs(True)
    # options.no_imgs(True).mute(True).no_js(True)
    # options.set_argument('--auto-open-devtools-for-tabs', 'true') # we don't need this anymore
    for argument in arguments:
        options.set_argument(argument)
    return options

def _human_type2(element , text: str) -> None:
    """
    Types in a way reminiscent of a human, with a random delay in between 50ms to 100ms for every character
    :param element: Input element to type text to
    :param text: Input to be typed
    """

    for c in text:
        element.input(c)

        sleep(random.uniform(0.05, 0.1))

def make_standard (num) :
    ret = str(num)
    if len(ret) < 2 : ret = "0" + ret

    return ret 

def fill_input_data(page, dataRow) : 
    
    fName = dataRow["Name"].split()[0] # split string based on space to get first name
    lName = dataRow["Name"].split()[-1]# split string based on space to get last name

    # 2026-10-04 survey: privacy.deepsync.com rebuilt the form. Fields are now
    # first_name / last_name / emails[] / phone_numbers[] / address[] /
    # city[] / state[] / zip[] (ids *_ctx1 for the first row), a "Who is
    # this request for?" radio and a requests[] checkbox list. Turnstile and
    # #submit_button are unchanged. 0/105 runs got past the old #who_address.
    who = page.ele("tag:input@@name=request_type@@value=opt_out", timeout=5)
    if who:
        who.click(by_js=True)

    first_name = page.ele("tag:input@@id=first_name")
    first_name.clear()
    first_name.click()
    _human_type2(first_name, fName)

    last_name = page.ele("tag:input@@id=last_name")
    last_name.clear()
    last_name.click()
    _human_type2(last_name, lName)

    email_input = page.ele("tag:input@@id=email_ctx1")
    email_input.clear()
    email_input.click()
    _human_type2(email_input, generate_email(dataRow["Name"]))

    phone_input = page.ele("tag:input@@id=phone_ctx1", timeout=2)
    if phone_input:
        phone_input.clear()
        phone_input.click()
        _human_type2(phone_input, (dataRow.get("Phone Number") or "").strip() or generate_phone_number())

    street_input = page.ele("tag:input@@id=who_address_ctx1")
    street_input.clear()
    street_input.click()
    _human_type2(street_input, dataRow["Address"])

    city_input = page.ele("tag:input@@id=who_city_ctx1")
    city_input.clear()
    city_input.click()
    _human_type2(city_input, dataRow["City"])

    state_select = page.ele("tag:select@@id=who_state_ctx1")
    __import__("lib.broker_helpers", fromlist=["select_state"]).select_state(state_select, dataRow["State"])

    zip_input = page.ele("tag:input@@id=who_zip_ctx1")
    zip_input.clear()
    zip_input.click()
    _human_type2(zip_input, str(dataRow["Zipcode"]))

    # "Do not sell or share" + "Please delete my personal information".
    for cb_id in ("request_type_1", "request_type_5"):
        cb = page.ele("tag:input@@id=" + cb_id, timeout=2)
        if cb and not cb.states.is_checked:
            cb.click(by_js=True)

def accudatacom(dataRow, website_name, in_user_email, run_mode) : 
    page = None
    try : 
        sucessConfirmationApi = f"https://privacypros.com/web/dashboard/appendapi.php?website={website_name}&status=1&api=true&email={in_user_email}"
        errorConfirmationApi = f"https://privacypros.com/web/dashboard/appendapi.php?website={website_name}&status=2&api=true&email={in_user_email}"
        
        fName = dataRow["Name"].split()[0] # split string based on space to get first name
        lName = dataRow["Name"].split()[-1]# split string based on space to get last name
        screenshot_save_path = screentShotDir + "\AccudataCom_" + fName + "-" + lName + ".png"
        arguments = [
            "-no-first-run",
            "--start-maximized",
            # "--incognito",
            "-disable-javascript",
            "-disable-gpu",
            "-disable-sensors",
        ]

        options = get_chromium_options(arguments).auto_port()
        
        if run_mode == "headless" :
            options.headless()

        # Launch Website
        page = ChromiumPage(addr_or_opts=options)
        # page.load_mode=None
        page.get("https://privacy.deepsync.com/")

        fill_input_data(page, dataRow)

        sleep(random.uniform(0.5, 1))

        print('Captcha is solving....')

        try:
            SITE_KEY = "0x4AAAAAAA1BRDtX53uNHQT_"
            result = solver.turnstile(sitekey=SITE_KEY, url="https://privacy.deepsync.com/")
            Code=result['code']
            print('Captcha is solve. Code:',Code)

        except Exception as e:
            print(e)
            raise Exception("removal---error----")
        
        sleep(0.3)

        __import__("lib.broker_helpers", fromlist=["set_turnstile_response"]).set_turnstile_response(page, Code)

        sleep(1)

        submit_button = page.ele("tag:button@@id=submit_button")
        submit_button.run_js("this.click();")        

        try :
            # response = requests.get(sucessConfirmationApi, timeout=10)
            print("Success Confirmation API is sent successfully!")
            sleep(5)
            page.get_screenshot(screenshot_save_path)
        except Exception as e:
            print("Success Confirmation API is failed: ", str(e))

        
    except Exception as e:
        try :
            # response = requests.get(errorConfirmationApi, timeout=10)
            print("Error Confirmation API is sent successfully!")
            sleep(5)
            page.get_screenshot(screenshot_save_path)
        except Exception as e:
            print("Error Confirmation API is failed: ", str(e))
        raise

    finally:
        if page is not None:
            try:
                page.quit()
            except Exception:
                pass

    return screenshot_save_path